This Java example was created via instructions provided by official AWS documentation, found here: https://docs.aws.amazon.com/codebuild/latest/userguide/getting-started.html

You can upload the "java-example.zip" file in this directory to an S3 bucket, and then configure it as a source for your AWS CodeBuild build project.
