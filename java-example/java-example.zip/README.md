This Java example was created via instructions provided by official AWS documentation, found here: https://docs.aws.amazon.com/codebuild/latest/userguide/getting-started.html
